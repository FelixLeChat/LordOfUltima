/*
 * token.h
 *
 *  Created on: Aug 27, 2013
 *      Author: francis
 */

#ifndef TOKEN_H_
#define TOKEN_H_

void task_tokenize(int in, int out_length, int out_string);

#endif /* TOKEN_H_ */
