/*
 * utils.h
 *
 *  Created on: 2014-02-05
 *      Author: francis
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <time.h>

void time_sub(struct timespec *res, struct timespec *x, struct timespec *y);

#endif /* UTILS_H_ */
