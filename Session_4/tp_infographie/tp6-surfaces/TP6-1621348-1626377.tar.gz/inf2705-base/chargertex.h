#ifndef _LOADTEX_H_
#define _LOADTEX_H_

#include <string.h>
#include <GL/glut.h>

bool ChargerTexture( std::string fichier, GLuint &texture );

#endif
